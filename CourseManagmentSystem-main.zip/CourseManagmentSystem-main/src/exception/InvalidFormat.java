package exception;

public class InvalidFormat extends RuntimeException{
    public InvalidFormat() {
        super("Invalid format!");
    }  
}
