package exception;

public class NullException extends RuntimeException {
		public NullException() {
			super("Please Fill the Empty Boxes");
		}

}
